/**
 * TutorChat Component - Interactive AI Tutor Chat Widget
 * 
 * A floating chat button that expands into a full conversation interface
 * with Professor Sage, the friendly AI tutor.
 * Now supports Vision mode - upload images for math problem solving!
 */
import { useState, useRef, useEffect } from 'react'
import {
    MessageCircle,
    X,
    Send,
    Loader2,
    Sparkles,
    HelpCircle,
    Camera,
    Mic,
    RotateCcw
} from 'lucide-react'
import { chatService } from '@/services/chat'
import { compressImage } from '@/utils/imageCompression'
import { VoiceMode } from './VoiceMode'
import type { ChatMessage, ChatContextType, ChatResponse } from '@/types'

interface TutorChatProps {
    /** Type of content being viewed */
    contextType: ChatContextType
    /** ID of the lesson or question being viewed */
    contextId?: string
    /** Whether to show the chat initially minimized */
    initiallyMinimized?: boolean
}

export function TutorChat({
    contextType,
    contextId,
    initiallyMinimized = true
}: TutorChatProps) {
    const [isOpen, setIsOpen] = useState(!initiallyMinimized)
    const [messages, setMessages] = useState<ChatMessage[]>([])
    const [inputValue, setInputValue] = useState('')
    const [isLoading, setIsLoading] = useState(false)
    const [sessionId, setSessionId] = useState<string | null>(null)
    const [suggestions, setSuggestions] = useState<string[]>([])
    const [imageAttachment, setImageAttachment] = useState<string | null>(null)
    const [isCompressing, setIsCompressing] = useState(false)
    const [showVoiceMode, setShowVoiceMode] = useState(false)
    const [isLoadingHistory, setIsLoadingHistory] = useState(false)
    const messagesEndRef = useRef<HTMLDivElement>(null)
    const inputRef = useRef<HTMLInputElement>(null)
    const fileInputRef = useRef<HTMLInputElement>(null)

    // Load session ID from localStorage on mount
    useEffect(() => {
        const storedSessionId = localStorage.getItem('tutor_chat_session_id')
        if (storedSessionId) {
            setSessionId(storedSessionId)
            loadHistory(storedSessionId)
        }
    }, [])

    // Save session ID to localStorage when it changes
    useEffect(() => {
        if (sessionId) {
            localStorage.setItem('tutor_chat_session_id', sessionId)
        }
    }, [sessionId])

    // Load chat history for a session
    const loadHistory = async (sid: string) => {
        setIsLoadingHistory(true)
        try {
            const history = await chatService.getHistory(sid)
            if (history.messages && history.messages.length > 0) {
                setMessages(history.messages)
            }
        } catch (error) {
            console.error('Failed to load chat history:', error)
            // Session might not exist anymore, clear it
            localStorage.removeItem('tutor_chat_session_id')
            setSessionId(null)
        } finally {
            setIsLoadingHistory(false)
        }
    }

    // Scroll to bottom when new messages arrive
    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
    }, [messages])

    // Focus input when chat opens
    useEffect(() => {
        if (isOpen) {
            inputRef.current?.focus()
        }
    }, [isOpen])

    // Handle image file selection
    const handleImageSelect = async (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0]
        if (!file) return

        if (!file.type.startsWith('image/')) {
            alert('Please select an image file')
            return
        }

        setIsCompressing(true)
        try {
            const compressedImage = await compressImage(file)
            setImageAttachment(compressedImage)
        } catch (error) {
            console.error('Image compression failed:', error)
            alert('Failed to process image. Please try again.')
        } finally {
            setIsCompressing(false)
        }

        // Reset file input
        if (fileInputRef.current) {
            fileInputRef.current.value = ''
        }
    }

    const handleRemoveImage = () => {
        setImageAttachment(null)
    }

    const handleSendMessage = async (message?: string) => {
        const text = message || inputValue.trim()
        if ((!text && !imageAttachment) || isLoading) return

        // Add user message immediately
        const userMessage: ChatMessage = {
            role: 'user',
            content: imageAttachment ? `${text} 📷` : text,
            timestamp: new Date().toISOString()
        }
        setMessages(prev => [...prev, userMessage])
        setInputValue('')
        const currentImage = imageAttachment
        setImageAttachment(null)
        setIsLoading(true)
        setSuggestions([])

        try {
            const response: ChatResponse = await chatService.askTutor({
                message: text || 'Please analyze this image.',
                context_type: contextType,
                context_id: contextId,
                session_id: sessionId || undefined,
                image_attachment: currentImage || undefined
            })

            // Save session ID for conversation continuity
            setSessionId(response.session_id)

            // Add AI response
            const aiMessage: ChatMessage = {
                role: 'assistant',
                content: response.response,
                timestamp: new Date().toISOString()
            }
            setMessages(prev => [...prev, aiMessage])

            // Set follow-up suggestions
            if (response.suggestions && response.suggestions.length > 0) {
                setSuggestions(response.suggestions)
            }
        } catch (error) {
            console.error('Chat error:', error)
            const errorMessage: ChatMessage = {
                role: 'assistant',
                content: "Oops! I had a little hiccup 🙈. Could you try asking again?",
                timestamp: new Date().toISOString()
            }
            setMessages(prev => [...prev, errorMessage])
        } finally {
            setIsLoading(false)
        }
    }

    const handleKeyPress = (e: React.KeyboardEvent) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault()
            handleSendMessage()
        }
    }

    const handleSuggestionClick = (suggestion: string) => {
        handleSendMessage(suggestion)
    }

    const handleNewChat = () => {
        // Clear current session
        setMessages([])
        setSessionId(null)
        setSuggestions([])
        localStorage.removeItem('tutor_chat_session_id')
    }
    if (!isOpen) {
        // Floating button (closed state)
        return (
            <button
                onClick={() => setIsOpen(true)}
                className="fixed bottom-6 right-6 w-16 h-16 bg-gradient-to-r from-purple-500 to-indigo-600 
                           rounded-full shadow-lg hover:shadow-xl transition-all duration-300 
                           flex items-center justify-center group z-50
                           hover:scale-110 active:scale-95"
                aria-label="Open AI Tutor Chat"
            >
                <div className="relative">
                    <MessageCircle className="w-7 h-7 text-white" />
                    <Sparkles className="w-4 h-4 text-yellow-300 absolute -top-2 -right-2 
                                         animate-pulse" />
                </div>

                {/* Tooltip */}
                <span className="absolute right-full mr-3 px-3 py-2 bg-gray-900 text-white 
                                 text-sm rounded-lg opacity-0 group-hover:opacity-100 
                                 transition-opacity whitespace-nowrap pointer-events-none">
                    Need help? Ask Professor Sage! 🦉
                </span>
            </button>
        )
    }

    // Expanded chat window
    return (
        <div className="fixed bottom-6 right-6 w-96 h-[500px] bg-white rounded-2xl shadow-2xl 
                        flex flex-col overflow-hidden z-50 border border-gray-200
                        animate-in slide-in-from-bottom-4 duration-300">

            {/* Header */}
            <div className="bg-gradient-to-r from-purple-500 to-indigo-600 px-4 py-3 
                            flex items-center justify-between">
                <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
                        <span className="text-2xl">🦉</span>
                    </div>
                    <div>
                        <h3 className="text-white font-semibold">Professor Sage</h3>
                        <p className="text-white/80 text-xs">Your AI Learning Buddy</p>
                    </div>
                </div>
                <div className="flex items-center gap-2">
                    <button
                        onClick={handleNewChat}
                        className="text-white/80 hover:text-white transition-colors p-1"
                        aria-label="New chat"
                        title="Start new conversation"
                    >
                        <RotateCcw className="w-5 h-5" />
                    </button>
                    <button
                        onClick={() => setShowVoiceMode(true)}
                        className="text-white/80 hover:text-white transition-colors p-1"
                        aria-label="Voice mode"
                        title="🎙️ Talk to Professor Sage"
                    >
                        <Mic className="w-5 h-5" />
                    </button>
                    <button
                        onClick={() => setIsOpen(false)}
                        className="text-white/80 hover:text-white transition-colors p-1"
                        aria-label="Close chat"
                    >
                        <X className="w-5 h-5" />
                    </button>
                </div>
            </div>

            {/* Messages Area */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50">
                {isLoadingHistory && (
                    <div className="text-center py-8">
                        <Loader2 className="w-8 h-8 animate-spin text-purple-500 mx-auto mb-2" />
                        <p className="text-gray-500 text-sm">Loading your conversation...</p>
                    </div>
                )}

                {!isLoadingHistory && messages.length === 0 && (
                    <div className="text-center py-8">
                        <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center 
                                        justify-center mx-auto mb-4">
                            <HelpCircle className="w-8 h-8 text-purple-500" />
                        </div>
                        <h4 className="text-gray-800 font-medium mb-2">Hi there! 👋</h4>
                        <p className="text-gray-500 text-sm">
                            I'm Professor Sage, your friendly tutor!<br />
                            Ask me anything about what you're learning.
                        </p>
                        <button
                            onClick={() => setShowVoiceMode(true)}
                            className="mt-4 px-4 py-2 bg-gradient-to-r from-purple-500 to-indigo-600 
                                       text-white rounded-full text-sm font-medium
                                       hover:shadow-lg transition-all flex items-center gap-2 mx-auto"
                        >
                            <Mic className="w-4 h-4" />
                            Talk to me instead!
                        </button>
                    </div>
                )}

                {messages.map((message, index) => (
                    <div
                        key={index}
                        className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
                    >
                        <div
                            className={`max-w-[80%] rounded-2xl px-4 py-2 ${message.role === 'user'
                                ? 'bg-purple-600 text-white rounded-br-sm'
                                : 'bg-white text-gray-800 shadow-sm border border-gray-100 rounded-bl-sm'
                                }`}
                        >
                            <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                        </div>
                    </div>
                ))}

                {isLoading && (
                    <div className="flex justify-start">
                        <div className="bg-white rounded-2xl px-4 py-3 shadow-sm border border-gray-100 
                                        rounded-bl-sm">
                            <div className="flex items-center gap-2">
                                <Loader2 className="w-4 h-4 animate-spin text-purple-500" />
                                <span className="text-sm text-gray-500">Thinking...</span>
                            </div>
                        </div>
                    </div>
                )}

                <div ref={messagesEndRef} />
            </div>

            {/* Suggestions */}
            {suggestions.length > 0 && !isLoading && (
                <div className="px-4 py-2 bg-purple-50 border-t border-purple-100">
                    <p className="text-xs text-purple-600 mb-2">Try asking:</p>
                    <div className="flex flex-wrap gap-2">
                        {suggestions.map((suggestion, index) => (
                            <button
                                key={index}
                                onClick={() => handleSuggestionClick(suggestion)}
                                className="text-xs px-3 py-1.5 bg-white border border-purple-200 
                                           rounded-full text-purple-700 hover:bg-purple-100 
                                           transition-colors"
                            >
                                {suggestion}
                            </button>
                        ))}
                    </div>
                </div>
            )}

            {/* Input Area */}
            <div className="p-3 border-t border-gray-200 bg-white">
                {/* Image Preview */}
                {imageAttachment && (
                    <div className="mb-2 relative inline-block">
                        <img
                            src={imageAttachment}
                            alt="Attached"
                            className="h-16 w-16 object-cover rounded-lg border border-gray-200"
                        />
                        <button
                            onClick={handleRemoveImage}
                            className="absolute -top-2 -right-2 w-5 h-5 bg-red-500 text-white 
                                       rounded-full flex items-center justify-center text-xs
                                       hover:bg-red-600 transition-colors"
                            aria-label="Remove image"
                        >
                            ×
                        </button>
                    </div>
                )}

                <div className="flex items-center gap-2">
                    {/* Hidden file input */}
                    <input
                        ref={fileInputRef}
                        type="file"
                        accept="image/*"
                        capture="environment"
                        onChange={handleImageSelect}
                        className="hidden"
                    />

                    {/* Camera/Image button */}
                    <button
                        onClick={() => fileInputRef.current?.click()}
                        disabled={isLoading || isCompressing}
                        className="w-10 h-10 bg-gray-100 rounded-full flex items-center 
                                   justify-center text-gray-600 hover:bg-gray-200 
                                   transition-colors disabled:opacity-50"
                        aria-label="Upload image"
                        title="📷 Snap a photo of a problem!"
                    >
                        {isCompressing ? (
                            <Loader2 className="w-5 h-5 animate-spin" />
                        ) : (
                            <Camera className="w-5 h-5" />
                        )}
                    </button>

                    <input
                        ref={inputRef}
                        type="text"
                        value={inputValue}
                        onChange={(e) => setInputValue(e.target.value)}
                        onKeyPress={handleKeyPress}
                        placeholder={imageAttachment ? "Describe what you need help with..." : "Ask me anything..."}
                        disabled={isLoading}
                        className="flex-1 px-4 py-2 bg-gray-100 rounded-full text-sm text-gray-900
                                   placeholder:text-gray-500
                                   focus:outline-none focus:ring-2 focus:ring-purple-500 
                                   focus:bg-white transition-all disabled:opacity-50"
                    />
                    <button
                        onClick={() => handleSendMessage()}
                        disabled={(!inputValue.trim() && !imageAttachment) || isLoading}
                        className="w-10 h-10 bg-purple-600 rounded-full flex items-center 
                                   justify-center text-white hover:bg-purple-700 
                                   transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                        aria-label="Send message"
                    >
                        {isLoading ? (
                            <Loader2 className="w-5 h-5 animate-spin" />
                        ) : (
                            <Send className="w-5 h-5" />
                        )}
                    </button>
                </div>
            </div>

            {/* Voice Mode Modal */}
            {showVoiceMode && (
                <VoiceMode onClose={() => setShowVoiceMode(false)} />
            )}
        </div>
    )
}

export default TutorChat
