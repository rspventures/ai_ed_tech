"""AI Tutor Platform - Application package."""
