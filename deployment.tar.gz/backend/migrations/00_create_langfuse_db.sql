-- Create Langfuse database for LLM observability
-- This script runs on first PostgreSQL initialization

CREATE DATABASE langfuse;
